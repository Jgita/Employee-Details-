import { Component } from '@angular/core';

export interface Employee {
    employee_name: string;
    employee_salary: string;
    employee_age: string;
}
